"""
command_listener.py v2 — Local-First Architecture.

Xu ly cac lenh tu xa tu Web App.
v2: Ho tro reload_rules tuc thi, truyen phan hoi va khoa may trong < 2s.
"""
from utils.config import DEVICE_NAME
from monitor.screenshot import take_screenshot, make_screenshot_filename
from monitor.time_checker import is_within_allowed_time
from monitor.blocker import start_blocker


def process_pending_commands(supabase):
    """
    Lang nghe va thuc thi cac lenh tuc thi tu Web App.
    Cac lenh ho tro: take_screenshot, force_update, pause_control, resume_control, reload_rules.
    """
    try:
        res = supabase.table("system_commands")\
            .select("*")\
            .eq("device_name", DEVICE_NAME)\
            .eq("status", "pending")\
            .execute()

        commands = res.data or []
        if not commands:
            return

        # Lazy import SyncWorker de keo rules lap tuc khi co lenh
        from storage.sync_worker import SyncWorker
        sync = SyncWorker(supabase)

        for cmd in commands:
            cmd_id = cmd["id"]
            cmd_type = cmd["command"]
            print(f"[CMD] Nhan lenh tu Web: {cmd_type}")

            if cmd_type == "take_screenshot":
                try:
                    image_bytes, _ = take_screenshot(force_upload=True)
                    filename = make_screenshot_filename()

                    supabase.storage.from_("screenshots").upload(
                        path=filename,
                        file=image_bytes,
                        file_options={"content-type": "image/jpeg", "upsert": "true"}
                    )

                    supabase.table("screenshot_logs").insert({
                        "device_name": DEVICE_NAME,
                        "file_path": filename
                    }).execute()
                    print(f"[CMD] Da chup anh tuc thi: {filename}")
                except Exception as e:
                    print(f"[ERR] Screenshot command failed: {e}")

            elif cmd_type in ("reload_rules", "time_config_changed", "app_rules_changed"):
                print("[CMD] Nhan lenh reload_rules -> Keo quy tac moi ngay lap tuc...")
                try:
                    sync.pull_rules()
                    # Kiem tra quyen & thoi gian ngay lap tuc
                    allowed, reason = is_within_allowed_time(supabase)
                    if not allowed:
                        print(f"[CMD] [BLOCK] Ngoai gio cho phep ngay sau khi reload: {reason}")
                        start_blocker(supabase)
                except Exception as e:
                    print(f"[ERR] reload_rules failed: {e}")

            elif cmd_type == "force_update":
                print("[CMD] Nhan lenh force_update -> Keo rules & De Watchdog cap nhat.")
                try:
                    sync.pull_rules()
                    supabase.table("system_events").insert({
                        "device_name": DEVICE_NAME,
                        "event_type": "force_update_received",
                        "message": "Core agent received force_update. Watchdog will handle."
                    }).execute()
                except Exception:
                    pass
                continue

            elif cmd_type == "pause_control":
                print("[CMD] Nhan lenh tam dung dieu khien")
                try:
                    sync.pull_rules()
                except Exception:
                    pass

            elif cmd_type == "resume_control":
                print("[CMD] Nhan lenh tiep tuc dieu khien")
                try:
                    sync.pull_rules()
                except Exception:
                    pass

            else:
                print(f"[CMD] Lenh khong xac dinh: {cmd_type}")

            # Danh dau lenh da hoan thanh (tru force_update)
            try:
                supabase.table("system_commands")\
                    .update({"status": "completed"})\
                    .eq("id", cmd_id)\
                    .execute()
            except Exception as e:
                print(f"[ERR] Khong the cap nhat status command: {e}")

    except Exception as e:
        print(f"[ERR] Loi xu ly system_commands: {e}")

