"""
screenshot.py v2 — Chup man hinh voi Image Diff algorithm.
Chi upload anh moi khi co su thay doi dang ke so voi anh truoc do.
"""
import io
from datetime import datetime, timezone
from typing import Optional

from mss import mss
from PIL import Image, ImageDraw, ImageChops
from utils.config import DEVICE_NAME

# Luu anh truoc do de so sanh
_previous_thumbnail: Optional[Image.Image] = None

# Nguong thay doi: 5% pixel khac biet moi upload
DIFF_THRESHOLD: float = 0.05
COMPARE_SIZE: tuple[int, int] = (320, 180)
PIXEL_TOLERANCE: int = 30


def _compute_change_ratio(current: Image.Image, previous: Image.Image) -> float:
    """
    So sanh 2 anh bang pixel diff.
    Tra ve ty le pixel thay doi (0.0 ~ 1.0).
    """
    try:
        cur_small = current.resize(COMPARE_SIZE)
        prev_small = previous.resize(COMPARE_SIZE)
        
        diff = ImageChops.difference(cur_small, prev_small)
        diff_pixels = diff.getdata()
        
        changed = 0
        total = len(diff_pixels)
        for pixel in diff_pixels:
            # pixel la tuple (R, G, B)
            if max(pixel) > PIXEL_TOLERANCE:
                changed += 1
        
        return changed / total if total > 0 else 0.0
    except Exception:
        # Neu loi so sanh -> coi nhu da thay doi
        return 1.0


def has_significant_change(current_img: Image.Image) -> bool:
    """
    Kiem tra anh hien tai co thay doi dang ke so voi anh truoc do khong.
    Lan dau luon tra ve True (chua co anh truoc).
    """
    global _previous_thumbnail
    
    if _previous_thumbnail is None:
        _previous_thumbnail = current_img.copy()
        return True
    
    ratio = _compute_change_ratio(current_img, _previous_thumbnail)
    
    if ratio > DIFF_THRESHOLD:
        _previous_thumbnail = current_img.copy()
        return True
    
    return False


def take_screenshot(force_upload: bool = False) -> tuple[bytes, bool]:
    """
    Chup toan bo tat ca man hinh (ho tro 2 man tro len).
    
    Returns:
        tuple[bytes, bool]: (image_bytes, should_upload)
        - should_upload = True neu anh co thay doi dang ke hoac force_upload=True
    """
    with mss() as sct:
        # monitors[0] = toan bo vung ao chua tat ca man hinh
        monitor = sct.monitors[0]
        screenshot = sct.grab(monitor)
        
        # Chuyen sang PIL Image
        img = Image.frombytes("RGB", screenshot.size, screenshot.bgra, "raw", "BGRX")
        
        # Giam kich thuoc de tiet kiem dung luong
        img.thumbnail((1920, 1080))

        # Them timestamp vao anh (chu to va ro)
        draw = ImageDraw.Draw(img)
        time_str = datetime.now().strftime("%H:%M:%S  %d/%m/%Y")
        
        font = None
        try:
            from PIL import ImageFont
            font = ImageFont.truetype("arial.ttf", 36)
        except Exception:
            try:
                from PIL import ImageFont
                font = ImageFont.truetype("C:\\Windows\\Fonts\\arial.ttf", 36)
            except Exception:
                font = None

        x, y = 25, 25
        for dx in range(-2, 3):
            for dy in range(-2, 3):
                if dx != 0 or dy != 0:
                    draw.text((x + dx, y + dy), time_str, fill="black", font=font)
        # Chu mau xanh la (neon green) noi bat
        draw.text((x, y), time_str, fill="#00ff00", font=font)
        
        # Kiem tra thay doi
        should_upload = force_upload or has_significant_change(img)
        
        # Chuyen thanh bytes JPEG
        buffer = io.BytesIO()
        img.save(buffer, format="JPEG", quality=75)
        buffer.seek(0)
        
        return buffer.getvalue(), should_upload


def make_screenshot_filename() -> str:
    """Tao ten file screenshot theo UTC timestamp."""
    now = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    return f"{DEVICE_NAME}/{now}.jpg"